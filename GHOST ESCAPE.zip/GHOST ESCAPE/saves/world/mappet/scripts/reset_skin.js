function main(c)
{        
    var skin = c.getSubject().getStates().getString("skin");
    var mode = c.getSubject().getStates().getNumber("mode");    
                   
           if (mode == 0)
           {
                     c.executeCommand('/morph @p blockbuster.alex {Skin:"'+skin+'",Settings:{Hands:1b}}');
           }
           if (mode == 1)
           {
                     c.executeCommand('/morph @p blockbuster.fred {Skin:"'+skin+'",Settings:{Hands:1b}}');
           }
}