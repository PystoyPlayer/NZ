function main(c)
{
    //setair
    c.executeCommand("/setblock 4 11 -3 air")//
    c.executeCommand("/setblock -13 11 -26 air")//
    c.executeCommand("/setblock -15 11 7 air")//
    c.executeCommand("/setblock -3 11 7 air")//
    c.executeCommand("/setblock 23 12 0 air")//
    c.executeCommand("/setblock 5 12 5 air")//
    c.executeCommand("/setblock 24 10 -15 air")//
    c.executeCommand("/setblock 21 12 -26 air")//
    c.executeCommand("/setblock 15 12 -3 air")//
    c.executeCommand("/setblock -15 12 9 air")//
    c.executeCommand("/setblock -17 10 -10 air")//
    c.executeCommand("/setblock 8 11 -10 air")//
    c.executeCommand("/setblock -1 12 -10 air")//
    c.executeCommand("/setblock 12 10 -29 air")//
    c.executeCommand("/setblock 32 10 9 air")//
    //random
    min = 1;
    max = 6;
    var random = Math.floor(Math.random() * (max - min) + min);
     
    if (random == 1)
    {
      c.executeCommand("/setblock 32 10 9 tommy:gasblock")
      c.executeCommand("/setblock 4 11 -3 tommy:gasblock")
      c.executeCommand("/setblock 23 12 0 tommy:gasblock")
    }
    if (random == 2)
    {
      c.executeCommand("/setblock -17 10 -10 tommy:gasblock")
      c.executeCommand("/setblock 5 12 5 tommy:gasblock")
      c.executeCommand("/setblock 12 10 -29 tommy:gasblock")
    }
    if (random == 3)
    {
      c.executeCommand("/setblock 15 12 -3 tommy:gasblock")
      c.executeCommand("/setblock -15 12 9 tommy:gasblock")
      c.executeCommand("/setblock -1 12 -10 tommy:gasblock")
    }
    if (random == 4)
    {
      c.executeCommand("/setblock 8 11 -10 tommy:gasblock")
      c.executeCommand("/setblock -3 11 7 tommy:gasblock")
      c.executeCommand("/setblock -13 11 -26 tommy:gasblock")
    }
    if (random == 5)
    {
      c.executeCommand("/setblock -15 11 7 tommy:gasblock")
      c.executeCommand("/setblock 24 10 -15 tommy:gasblock")
      c.executeCommand("/setblock 21 12 -26 tommy:gasblock")
    }
}