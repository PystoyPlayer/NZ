function main(c)
{
    min = 1;
    max = 8;
    var random = Math.floor(Math.random() * (max - min) + min);
    c.executeCommand("/tp @a 0 5 0 180 0"); 
    if (random == 1)
    {
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] -12 10 -9"); 
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 20 10 -19");
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 10 10 2");
      c.executeCommand("/tp @a[x=0,y=6,z=0,r=5] -12 10 10");
    }
    if (random == 2)
    {
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] -16 10, 5"); 
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] -16 10, -9");
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 1 10 -24");
      c.executeCommand("/tp @a[x=0,y=6,z=0,r=5] 12 10 -4");
    }
    if (random == 3)
    {
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 12 10 -12"); 
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 20 10 10");
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 1 10 6");
      c.executeCommand("/tp @a[x=0,y=6,z=0,r=5] -4 10 -1");
    }
    if (random == 4)
    {
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] -8 10 -13"); 
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] -8 10 -7");
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 5 10 -17");
      c.executeCommand("/tp @a[x=0,y=6,z=0,r=5] 11 10 -22");
    }
    if (random == 5)
    {
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 11 10 -28"); 
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 20 10 -1");
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] -4 10 -15");
      c.executeCommand("/tp @a[x=0,y=6,z=0,r=5] 16 10 -10");
    }
    if (random == 6)
    {
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] -4 10, 3"); 
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] -12 10 -9");
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 16 10 -20");
      c.executeCommand("/tp @a[x=0,y=6,z=0,r=5] 6 10 -10");
    }
    if (random == 7)
    {
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 20 10 1"); 
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 5 10 -25");
      c.executeCommand("/tp @r[x=0,y=6,z=0,r=5] 7 10 -11");
      c.executeCommand("/tp @a[x=0,y=6,z=0,r=5] 3 10 -2");
    }
}