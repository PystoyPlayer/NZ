function main(c)
{
    var serv = c.getServer();
    var gen = serv.getStates().getNumber("gen");
    var flap = serv.getStates().getNumber("flap");
    var task_done = serv.getStates().getNumber("task_done");
    var players = c.getServer().getAllPlayers()
    var game = serv.getStates().getNumber("game");
    var gen_done = serv.getStates().getNumber("gen_done");
    
                                                                    
   var tasks1 = mappet.createMorph("{Label:\"[aОткрыт\",Name:\"label\"}");
   var tasks = mappet.createMorph("{Background:-1577058304,Max:157,Label:\"[7Щитков активно: [6"+flap+"/5 [7Генераторов починено: [6"+gen+"/3 [7Выход:         \",Name:\"label\"}");
   if (game == 1)  
   {
       if (task_done == 1)
        {
            for (var i in players)
            {
                var player = players[i];
                
                player.changeHUDMorph("tasks", 1, tasks1);    
                player.changeHUDMorph("tasks", 0, tasks);           
            }  
        }
        else if (flap == 5 && gen == 3)
        {
            c.executeCommand("/mp state set ~ task_done 1")
            c.executeCommand("/fill 2 10 12 4 12 13 air") 
            c.executeCommand("/clone -1 20 19 -3 18 18 2 10 12") 
            c.executeCommand("/setblock 3 11 16 tommy:door2fake")
            c.executeCommand("/execute @a ~ ~ ~ /playsound mp.sounds:door_open master @p 0 100 -7 1000000 1")
        }
        else if (gen == 3)
        {
           if (gen_done == 0)   
           {
               c.executeCommand("/mp script exec @r set_flap.js")
               c.executeCommand("/mp state set ~ gen_done 1")
           }
        }
            for (var i in players)
            {
                var player = players[i];
                
                player.changeHUDMorph("tasks", 0, tasks);
            }      
   }              
}