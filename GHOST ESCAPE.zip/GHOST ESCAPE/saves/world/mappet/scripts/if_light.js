function main(c)
{
    var s = c.getSubject();
    var players = c.getServer().getEntities("@a[mpe=light==1]");
    var empty = null

    for each (var player in players)
    {
        if (player.isEntityInRadius(s, 7))
        {
            s.setTarget(player)
        }     
    }
}    