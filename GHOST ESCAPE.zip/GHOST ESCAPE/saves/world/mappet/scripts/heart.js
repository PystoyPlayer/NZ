function main(c)
{
    // Code...
    var s = c.getSubject();
    var heart = s.getStates().getNumber("heart")
    
    if (heart == 1)
    {
        c.executeCommand("/mp hud close @s heart0")
        c.executeCommand("/mp hud setup @s heart1")
        c.executeCommand("/mp hud close @s heart3")
        c.executeCommand("/mp hud close @s heart2")
    }
    if (heart == 2)
    {
        c.executeCommand("/mp hud close @s heart0")
        c.executeCommand("/mp hud setup @s heart2")
        c.executeCommand("/mp hud close @s heart3")
        c.executeCommand("/mp hud close @s heart1")
    }
    if (heart == 3)
    {
        c.executeCommand("/mp hud close @s heart0")
        c.executeCommand("/mp hud setup @s heart3")
        c.executeCommand("/mp hud close @s heart1")
        c.executeCommand("/mp hud close @s heart2")
    }
}