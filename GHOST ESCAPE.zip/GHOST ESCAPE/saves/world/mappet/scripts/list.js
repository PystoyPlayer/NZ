function main(c)
{
            var ui = mappet.createUI(c, "handler").closable(true)
            var buttonok = ui.button("Выход").id("buttonok");
            buttonok.rxy(0.23, 0.9).wh(500, 30).anchor(0);  
            c.executeCommand("mp hud setup @s info")     
            var s = c.getSubject();
            s.openUI(ui);   
}
function handler(c)
{
    var s = c.getSubject();  
    var uiContext = s.getUIContext();          
        if (uiContext.getLast() === "buttonok")
        {
               s.swingArm();
               s.closeUI();   
               c.executeCommand("mp hud close @s info")        
        }
}            