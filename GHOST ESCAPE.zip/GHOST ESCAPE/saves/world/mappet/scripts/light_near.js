function main(c)
{
    var s = c.getSubject();
    var near = s.getStates().getNumber("near")
    var light = s.getStates().getNumber("light");
    var light1 = s.getStates().getNumber("light1");
    var players = c.getServer().getEntities("@e[mpid=bot]");

    if (light == 1)
    {
        for each (var player in players)
        {
            if (player.isEntityInRadius(s, 10))
            {
                    if (light1 == 0)
                    {   
                          c.executeCommand('mp state set @s light1 1');
                    } 
                    if (light1 == 1)
                    {       
                          c.executeCommand('mp state set @s light1 0');                                                         
                    }  
                    c.executeCommand('/mp event trigger @s near');   
                    c.executeCommand("mp state set @s near 1")  
            }
        }
    }
    else
    {
        c.executeCommand("mp state set @s near 0")
        c.executeCommand('mp state set @s light1 0');       
    }
}