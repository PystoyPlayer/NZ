function main(c)
{
    //setair
    c.executeCommand("setblock 9 11 1 air")//
    c.executeCommand("setblock 11 11 -9 air")///
    c.executeCommand("setblock 10 11 -13 air")
    c.executeCommand("setblock 9 12 -15 air")///
    c.executeCommand("setblock -2 10 -6 air")//
    c.executeCommand("setblock -3 11 3 air")
    c.executeCommand("setblock 2 10 11 air")///
    c.executeCommand("setblock 19 12 -16 air")
    c.executeCommand("setblock 15 11 -20 air")//
    c.executeCommand("setblock 2 12 -30 air")
    c.executeCommand("setblock -7 10 -7 air")///
    c.executeCommand("setblock 13 10 5 air")//
    //random
    min = 1;
    max = 4;
    var random = Math.floor(Math.random() * (max - min) + min);
     
    if (random == 1)
    {
      c.executeCommand("setblock 13 10 5 tommy:medkit")
      c.executeCommand("setblock 15 11 -20 tommy:medkit")
      c.executeCommand("setblock -2 10 -6 tommy:medkit")
      c.executeCommand("setblock 9 11 1 tommy:medkit")
    }
    if (random == 2)
    {
      c.executeCommand("setblock -7 10 -7 tommy:medkit")
      c.executeCommand("setblock 2 10 11 tommy:medkit")
      c.executeCommand("setblock 9 12 -15 tommy:medkit")
      c.executeCommand("setblock 11 11 -9 tommy:medkit")
    }
    if (random == 3)
    {
      c.executeCommand("setblock 2 12 -30 tommy:medkit")
      c.executeCommand("setblock 19 12 -16 tommy:medkit")
      c.executeCommand("setblock -3 11 3 tommy:medkit")
      c.executeCommand("setblock 10 11 -13` tommy:medkit")
    }
}