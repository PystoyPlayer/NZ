function main(c)
{   
     var pos = c.getSubject().getPosition()
     
     //door1
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z-1), "tommy:door2fake", 1))
     {
                c.executeCommand('/setblock ~ ~1 ~-1 tommy:door2 3')
     }  
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2fake", 1))
     {
                c.executeCommand('/setblock ~ ~1 ~ tommy:door2 3')
     } 
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z+1), "tommy:door2", 1))
     {
                c.executeCommand('/setblock ~ ~1 ~1 tommy:door2fake 3')
     }  
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z-2), "tommy:door2", 1))
     {
                c.executeCommand('/setblock ~ ~1 ~-2 tommy:door2fake 3')
     }  
     if (c.getWorld().testForBlock(Math.floor(pos.x-1), Math.floor(pos.y+1), Math.floor(pos.z-1), "tommy:door2", 1))
     {
                c.executeCommand('/setblock ~-1 ~1 ~-1 tommy:door2fake 3')
     }  
     if (c.getWorld().testForBlock(Math.floor(pos.x+1), Math.floor(pos.y+1), Math.floor(pos.z-1), "tommy:door2", 1))
     {
                c.executeCommand('/setblock ~1 ~1 ~-1 tommy:door2fake 3')
     }  
     //door2
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2fake", 2))
     {
                c.executeCommand('/setblock ~ ~1 ~ tommy:door2 4')
     }  
     if (c.getWorld().testForBlock(Math.floor(pos.x-1), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2", 2))
     {
                c.executeCommand('/setblock ~-1 ~1 ~ tommy:door2fake 4')
     } 
     if (c.getWorld().testForBlock(Math.floor(pos.x+1), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2fake", 2))
     {
                c.executeCommand('/setblock ~1 ~1 ~ tommy:door2 4')
     }  
     if (c.getWorld().testForBlock(Math.floor(pos.x+2), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2", 2))
     {
                c.executeCommand('/setblock ~2 ~1 ~ tommy:door2fake 4')
     }  
     if (c.getWorld().testForBlock(Math.floor(pos.x+1), Math.floor(pos.y+1), Math.floor(pos.z+1), "tommy:door2", 2))
     {
                c.executeCommand('/setblock ~1 ~1 ~1 tommy:door2fake 4')
     } 
     if (c.getWorld().testForBlock(Math.floor(pos.x+1), Math.floor(pos.y+1), Math.floor(pos.z-1), "tommy:door2", 2))
     {
                c.executeCommand('/setblock ~1 ~1 ~-1 tommy:door2fake 4')
     } 
     //door3 
     if (c.getWorld().testForBlock(Math.floor(pos.x-1), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2fake", 3))
     {
                c.executeCommand('/setblock ~-1 ~1 ~ tommy:door2 5')
     }  
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2fake", 3))
     {
                c.executeCommand('/setblock ~ ~1 ~ tommy:door2 5')
     }
     if (c.getWorld().testForBlock(Math.floor(pos.x+1), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2", 3))
     {
                c.executeCommand('/setblock ~1 ~1 ~ tommy:door2fake 5')
     }    
     var s = c.getSubject()
     var name = s.getName()
     var gm = s.getGameMode();
     var top = "deop"
     c.executeCommand(top+" "+name) 
     if (gm == 1)
     {
       s.setGameMode(2);
     }
     if (gm == 0)
     {
       s.setGameMode(2);
     }
     if (c.getWorld().testForBlock(Math.floor(pos.x-2), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2", 3))
     {
                c.executeCommand('/setblock ~-2 ~1 ~ tommy:door2fake 5')
     }          
     if (c.getWorld().testForBlock(Math.floor(pos.x-1), Math.floor(pos.y+1), Math.floor(pos.z+1), "tommy:door2", 3))
     {
                c.executeCommand('/setblock ~-1 ~1 ~1 tommy:door2fake 5')
     } 
     if (c.getWorld().testForBlock(Math.floor(pos.x-1), Math.floor(pos.y+1), Math.floor(pos.z-1), "tommy:door2", 3))
     {
                c.executeCommand('/setblock ~-1 ~1 ~-1 tommy:door2fake 5')
     }  
     //door4  
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z), "tommy:door2fake", 4))
     {
                c.executeCommand('/setblock ~ ~1 ~ tommy:door2 2')
     }   
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z+1), "tommy:door2fake", 4))
     {
                c.executeCommand('/setblock ~ ~1 ~1 tommy:door2 2')
     }
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z-1), "tommy:door2", 4))
     {
                c.executeCommand('/setblock ~ ~1 ~-1 tommy:door2fake 2')
     }
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z+2), "tommy:door2", 4))
     {
                c.executeCommand('/setblock ~ ~1 ~2 tommy:door2fake 2')
     }   
     if (c.getWorld().testForBlock(Math.floor(pos.x), Math.floor(pos.y+1), Math.floor(pos.z+2), "tommy:door2", 4))
     {
                c.executeCommand('/setblock ~ ~1 ~2 tommy:door2fake 2')
     } 
     if (c.getWorld().testForBlock(Math.floor(pos.x+1), Math.floor(pos.y+1), Math.floor(pos.z+1), "tommy:door2", 4))
     {
                c.executeCommand('/setblock ~1 ~1 ~1 tommy:door2fake 2')
     } 
     if (c.getWorld().testForBlock(Math.floor(pos.x-1), Math.floor(pos.y+1), Math.floor(pos.z+1), "tommy:door2", 4))
     {
                c.executeCommand('/setblock ~-1 ~1 ~1 tommy:door2fake 2')
     }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
}