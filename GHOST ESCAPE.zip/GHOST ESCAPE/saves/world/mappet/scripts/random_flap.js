function main(c)
{
    //set air
    c.executeCommand("/setblock -16 11 -26 air")
    c.executeCommand("/setblock -4 11 -26 air")
    c.executeCommand("/setblock 1 11 -30 air")
    c.executeCommand("/setblock -10 11 -18 air")
    c.executeCommand("/setblock 8 11 -21 air")
    c.executeCommand("/setblock 25 11 -7 air")
    c.executeCommand("/setblock 25 11 -3 air")
    c.executeCommand("/setblock 16 11 -1 air")
    c.executeCommand("/setblock -17 11 10 air")
    c.executeCommand("/setblock -11 11 -5 air")
    
        
    min = 1;
    max = 6;
    var random = Math.floor(Math.random() * (max - min) + min);
     

    if (random == 1)
    {
      c.executeCommand("/setblock -16 11 -26 tommy:flap000 3")
      c.executeCommand("/setblock -17 11 10 tommy:flap000 5")
      c.executeCommand("/setblock 25 11 -3 tommy:flap000 4")
      c.executeCommand("/setblock 1 11 -30 tommy:flap000 3")
      c.executeCommand("/setblock -10 11 -18 tommy:flap000 3")
    }
    if (random == 2)
    {
      c.executeCommand("/setblock 8 11 -21 tommy:flap000 4")
      c.executeCommand("/setblock 25 11 -7 tommy:flap000 4")
      c.executeCommand("/setblock -17 11 10 tommy:flap000 5")
      c.executeCommand("/setblock -4 11 -26 tommy:flap000 3")
      c.executeCommand("/setblock -11 11 -5 tommy:flap000 4")
    }
    if (random == 3)
    {
      c.executeCommand("/setblock -10 11 -18 tommy:flap000 3")
      c.executeCommand("/setblock 25 11 -3 tommy:flap000 4")
      c.executeCommand("/setblock -16 11 -26 tommy:flap000 3")
      c.executeCommand("/setblock 16 11 -1 tommy:flap000 2")
      c.executeCommand("/setblock -17 11 10 tommy:flap000 5")
    }
    if (random == 4)
    {
      c.executeCommand("/setblock 1 11 -30 tommy:flap000 3")
      c.executeCommand("/setblock 8 11 -21 tommy:flap000 4")
      c.executeCommand("/setblock 25 11 -7 tommy:flap000 4")
      c.executeCommand("/setblock 16 11 -1 tommy:flap000 2")
      c.executeCommand("setblock -10 11 -18 tommy:flap000 3")
    }
    if (random == 5)
    {
      c.executeCommand("/setblock -10 11 -18 tommy:flap000 3")
      c.executeCommand("/setblock 1 11 -30 tommy:flap000 3")
      c.executeCommand("/setblock 25 11 -7 tommy:flap000 4")
      c.executeCommand("/setblock 25 11 -3 tommy:flap000 4")
      c.executeCommand("/setblock -4 11 -26 tommy:flap000 3")
    }
}