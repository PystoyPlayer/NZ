function main(c)
{
    c.executeCommand("/mp npc despawn @e")
    c.getWorld().spawnNpc("bot", "default", 0, 10, 0); 
    c.executeCommand("/tp @e[type=mappet:npc] 3 10 10")
}