function main(c)
{
    //setair
    c.executeCommand("/setblock 12 11 -9 air")//
    c.executeCommand("/setblock -11 12 2 air")//
    c.executeCommand("/setblock -11 12 -6 air")//
    c.executeCommand("/setblock -3 12 -25 air")//
    c.executeCommand("/setblock 14 10 -37 air")//
    c.executeCommand("/setblock 19 11 -14 air")//
    c.executeCommand("/setblock 4 11 9 air")//
    c.executeCommand("/setblock 11 12 1 air")//
    c.executeCommand("/setblock 17 12 2 air")//
    c.executeCommand("/setblock -1 11 -24 air")//
    //random
    min = 1;
    max = 6;
    var random = Math.floor(Math.random() * (max - min) + min);
     
    if (random == 1)
    {
      c.executeCommand("/setblock -11 12 -6 tommy:tongs")
      c.executeCommand("/setblock 12 11 -9 tommy:tongs");
    }
    if (random == 2)
    {
      c.executeCommand("/setblock 19 11 -14 tommy:tongs")
      c.executeCommand("/setblock 4 11 9 tommy:tongs")
    }
    if (random == 3)
    {
      c.executeCommand("/setblock 14 10 -37 tommy:tongs")
      c.executeCommand("/setblock 11 12 1 tommy:tongs")
    }
    if (random == 4)
    {
      c.executeCommand("/setblock -11 12 2 tommy:tongs")
      c.executeCommand("/setblock -3 12 -25 tommy:tongs")
    }
    if (random == 5)
    {
      c.executeCommand("/setblock 17 12 2 tommy:tongs")
      c.executeCommand("/setblock -1 11 -24 tommy:tongs")
    }
}