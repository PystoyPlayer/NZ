function main(c)
{
    //set air
    c.executeCommand("/setblock -10 10 -31 air")
    c.executeCommand("/setblock -22 10 -13 air")
    c.executeCommand("/setblock -22 10 5 air")
    c.executeCommand("/setblock 15 10 3 air")
    c.executeCommand("/setblock 29 10 6 air")
    c.executeCommand("/setblock 11 10 -17 air")
    c.executeCommand("/setblock 22 10 -24 air")
    c.executeCommand("/setblock 11 10 -34 air")
    c.executeCommand("/setblock 1 10 -10 air")
    
    //random
    min = 1;
    max = 6;
    var random = Math.floor(Math.random() * (max - min) + min);
     

    if (random == 1)
    {
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 3), -22, 10, 5);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 3), 1, 10, -10);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 2), 29, 10, 6);
    }  
    if (random == 2)
    {
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 3), -22, 10, -13);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 1), 15, 10, 3);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 1), -10, 10, -31);
    }  
    if (random == 3)
    {
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 3), -22, 10, 5);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 1), 11, 10, -34);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 1), 22, 10, -24);
    }  
    if (random == 4)
    {
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 3), -22, 10, -13);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 1), 15, 10, 3);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 4), 11, 10, -17);
    }  
    if (random == 5)
    {
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 3), 1, 10, -10);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 1), -10, 10, -31);
      c.getWorld().setBlock(mappet.createBlockState("tommy:gen0", 2), 29, 10, 6);
    } 
}