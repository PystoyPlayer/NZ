function main(c)
{
    var s = c.getSubject()  
            //s.clearPatrolPoints();
            s.addPatrol(23, 10, 5, "AI_RandomSpawn.js", "stop")
            s.addPatrol(6, 10, -10, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-16, 10, -20, "AI_RandomSpawn.js", "")
            s.addPatrol(23, 10, -19, "AI_RandomSpawn.js", "stop")
            s.addPatrol(11, 10, -4, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-16, 10, 5, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-11, 10, -9, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-10, 10, -25, "AI_RandomSpawn.js", "stop")
            s.addPatrol(2, 10, -23, "AI_RandomSpawn.js", "stop")
            s.addPatrol(20, 10, -15, "AI_RandomSpawn.js", "stop")
            s.addPatrol(12, 10, -12, "AI_RandomSpawn.js", "stop")
            s.addPatrol(3, 10, 6, "AI_RandomSpawn.js", "stop")
            s.addPatrol(11, 10, -25, "AI_RandomSpawn.js", "stop")
            s.addPatrol(15, 10, 8, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-8, 10, -7, "AI_RandomSpawn.js", "stop")
            s.addPatrol(0, 10, 1, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-13, 10, -13, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-16, 10, -1, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-16, 10, -9, "AI_RandomSpawn.js", "stop")
            s.addPatrol(20, 10, -15, "AI_RandomSpawn.js", "stop")
            s.addPatrol(12, 10, -12, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-2, 10, -5, "AI_RandomSpawn.js", "stop")
            s.addPatrol(-4, 10, -18, "AI_RandomSpawn.js", "stop")   
            s.addPatrol(20, 10, -5, "AI_RandomSpawn.js", "stop")    
            s.addPatrol(3, 10, 10, "", "")             
}
function stop(c)
{
    var s = c.getSubject()
    var slowness = mappet.getPotion("slowness");
    var blind = mappet.getPotion("blindness");
    min = 1;
    max = 4;
    var random = Math.floor(Math.random() * (max - min) + min);
    if (random == 1)
    {
      s.applyPotion(slowness, 200, 255, false)
      s.applyPotion(blind, 200, 255, false)
    }
}