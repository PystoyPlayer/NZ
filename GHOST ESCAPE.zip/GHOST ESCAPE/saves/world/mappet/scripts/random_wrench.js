function main(c)
{
    //set air
    c.executeCommand("/setblock 8 12 -20 air")
    c.executeCommand("/setblock 22 11 -10 air")
    c.executeCommand("/setblock 24 12 -6 air")
    c.executeCommand("/setblock -13 12 -10 air")
    c.executeCommand("/setblock -13 11 -18 air")    
    //random        
    min = 1;
    max = 6;
    var random = Math.floor(Math.random() * (max - min) + min);
     
    if (random == 1)
    {
      c.executeCommand("/setblock -13 12 -10 tommy:fixkeyblock")
    }
    if (random == 2)
    {
      c.executeCommand("/setblock -13 11 -18 tommy:fixkeyblock")
    }
    if (random == 3)
    {
      c.executeCommand("/setblock 24 12 -6 tommy:fixkeyblock")
    }
    if (random == 4)
    {
      c.executeCommand("/setblock 22 11 -10 tommy:fixkeyblock")
    }
    if (random == 5)
    {
      c.executeCommand("/setblock 22 11 -10 tommy:fixkeyblock")
    }
}